import type { ReactNode } from "react";

type DetailDrawerSize = "md" | "lg" | "xl";

type DetailDrawerProps = {
  open: boolean;
  title: ReactNode;
  subtitle?: ReactNode;
  eyebrow?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  onClose: () => void;
  size?: DetailDrawerSize;
};

type DetailDrawerSectionProps = {
  title?: ReactNode;
  description?: ReactNode;
  children: ReactNode;
  className?: string;
};

type DetailDrawerFieldProps = {
  label: ReactNode;
  value?: ReactNode;
  children?: ReactNode;
  className?: string;
};

const drawerSizeClasses: Record<DetailDrawerSize, string> = {
  md: "max-w-xl",
  lg: "max-w-2xl",
  xl: "max-w-3xl",
};

export function DetailDrawer({
  open,
  title,
  subtitle,
  eyebrow,
  children,
  footer,
  onClose,
  size = "lg",
}: DetailDrawerProps) {
  if (!open) {
    return null;
  }

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <button
        type="button"
        aria-label="Detailansicht schließen"
        className="absolute inset-0 cursor-default bg-zinc-950/10 backdrop-blur-[1px]"
        onClick={onClose}
      />

      <aside
        role="dialog"
        aria-modal="true"
        aria-labelledby="detail-drawer-title"
        className={[
          "relative z-10 flex h-full w-full flex-col border-l border-zinc-200 bg-white shadow-2xl",
          drawerSizeClasses[size],
        ].join(" ")}
      >
        <header className="border-b border-zinc-200 px-6 py-5">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              {eyebrow && (
                <div className="mb-2 text-xs font-semibold uppercase tracking-[0.16em] text-indigo-600">
                  {eyebrow}
                </div>
              )}

              <h2
                id="detail-drawer-title"
                className="truncate text-xl font-semibold tracking-tight text-zinc-950"
              >
                {title}
              </h2>

              {subtitle && (
                <p className="mt-1 text-sm leading-6 text-zinc-500">
                  {subtitle}
                </p>
              )}
            </div>

            <button
              type="button"
              onClick={onClose}
              className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-zinc-200 bg-white text-xl leading-none text-zinc-500 transition hover:bg-zinc-50 hover:text-zinc-950"
              aria-label="Schließen"
            >
              ×
            </button>
          </div>
        </header>

        <div className="min-h-0 flex-1 overflow-y-auto px-6 py-5">
          {children}
        </div>

        {footer && (
          <footer className="border-t border-zinc-200 bg-zinc-50/80 px-6 py-4">
            <div className="flex flex-wrap items-center justify-end gap-2">
              {footer}
            </div>
          </footer>
        )}
      </aside>
    </div>
  );
}

export function DetailDrawerSection({
  title,
  description,
  children,
  className = "",
}: DetailDrawerSectionProps) {
  return (
    <section
      className={[
        "rounded-3xl border border-zinc-200 bg-white p-5 shadow-sm",
        className,
      ].join(" ")}
    >
      {(title || description) && (
        <div className="mb-4">
          {title && (
            <h3 className="text-sm font-semibold tracking-tight text-zinc-950">
              {title}
            </h3>
          )}

          {description && (
            <p className="mt-1 text-sm leading-6 text-zinc-500">
              {description}
            </p>
          )}
        </div>
      )}

      {children}
    </section>
  );
}

export function DetailDrawerField({
  label,
  value,
  children,
  className = "",
}: DetailDrawerFieldProps) {
  return (
    <div className={["min-w-0", className].join(" ")}>
      <dt className="text-xs font-semibold uppercase tracking-[0.12em] text-zinc-500">
        {label}
      </dt>
      <dd className="mt-1 text-sm font-medium text-zinc-950">
        {children ?? value ?? "—"}
      </dd>
    </div>
  );
}

export function DetailDrawerFieldGrid({
  children,
  columns = 2,
}: {
  children: ReactNode;
  columns?: 1 | 2 | 3;
}) {
  const columnClasses = {
    1: "grid-cols-1",
    2: "grid-cols-1 sm:grid-cols-2",
    3: "grid-cols-1 sm:grid-cols-2 xl:grid-cols-3",
  };

  return (
    <dl className={["grid gap-4", columnClasses[columns]].join(" ")}>
      {children}
    </dl>
  );
}
